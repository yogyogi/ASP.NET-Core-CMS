﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CMS.Models.ViewModels
{
    public class MediaDate
    {
        public int Id { get; set; }
        public string DateText { get; set; }
        public string DateValue { get; set; }
    }
}
