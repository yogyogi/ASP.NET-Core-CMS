﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CMS.Models.ViewModels
{
    public class Info
    {
        public string siteTitle { get; set; }

        public string siteDescription { get; set; }

        public string logo { get; set; }
    }
}
