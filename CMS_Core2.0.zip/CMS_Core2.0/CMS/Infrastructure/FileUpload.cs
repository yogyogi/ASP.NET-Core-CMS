﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CMS.Infrastructure
{
    public class FileUpload
    {
        public int id { get; set; }
        public string url { get; set; }
        public string name { get; set; }
    }
}
